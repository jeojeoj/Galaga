-- -------------------------------------------------------------------------
-- PostgreSQL SQL create tables
-- exported at Fri Nov 27 23:43:41 CET 2009 with easyDesigner
-- -------------------------------------------------------------------------

-- -------------------------------------------------------------------------
-- Table: Employee
-- -------------------------------------------------------------------------
CREATE TABLE "Employee" (
  "idEmployee" bigserial NOT NULL,
  "name" VARCHAR NULL,
  "address" VARCHAR NULL,
  "sex" BIT NULL,
  PRIMARY KEY ("idEmployee")
);

-- -------------------------------------------------------------------------
-- Table: Customer
-- -------------------------------------------------------------------------
CREATE TABLE "Customer" (
  "idCustomer" bigserial NOT NULL,
  "name" VARCHAR NULL,
  "address" VARCHAR NULL,
  "phone" VARCHAR NULL,
  "smartcard" INTEGER NULL,
  "discount" NUMERIC NULL DEFAULT '1.00',
  PRIMARY KEY ("idCustomer")
);

-- -------------------------------------------------------------------------
-- Table: News
-- -------------------------------------------------------------------------
CREATE TABLE "News" (
  "idNews" bigserial NOT NULL,
  "Customer_idCustomer" INTEGER NOT NULL,
  "date" DATE NULL,
  "content" VARCHAR NULL,
  "already_read" BOOL NULL DEFAULT 'FALSE',
  PRIMARY KEY ("idNews")
);

-- -------------------------------------------------------------------------
-- Table: Book
-- -------------------------------------------------------------------------
CREATE TABLE "Book" (
  "isbn" INTEGER NOT NULL,
  "Publisher_idPublisher" INTEGER NOT NULL,
  "author" VARCHAR NULL,
  "title" VARCHAR NULL,
  "pub_year" INTEGER NULL,
  "selling_price" NUMERIC NULL,
  "buying_price" NUMERIC NULL,
  "num_available" INTEGER NULL,
  "num_min" INTEGER NULL,
  "num_max" INTEGER NULL,
  PRIMARY KEY ("isbn")
);

-- -------------------------------------------------------------------------
-- Table: Publisher
-- -------------------------------------------------------------------------
CREATE TABLE "Publisher" (
  "idPublisher" bigserial NOT NULL,
  "name" VARCHAR NULL,
  "address" VARCHAR NULL,
  "phone" VARCHAR NULL,
  PRIMARY KEY ("idPublisher")
);

-- -------------------------------------------------------------------------
-- Table: BookOrder
-- -------------------------------------------------------------------------
CREATE TABLE "BookOrder" (
  "idBookOrder" bigserial NOT NULL,
  "Employee_idEmployee" INTEGER NULL,
  "Customer_idCustomer" INTEGER NULL,
  "date" DATE NULL,
  PRIMARY KEY ("idBookOrder")
);

-- -------------------------------------------------------------------------
-- Table: Order_consists_of
-- -------------------------------------------------------------------------
CREATE TABLE "Order_consists_of" (
  "BookOrder_idBookOrder" INTEGER NOT NULL,
  "Book_isbn" INTEGER NOT NULL,
  PRIMARY KEY ("BookOrder_idBookOrder", "Book_isbn")
);

-- -------------------------------------------------------------------------
-- Table: Invoice
-- -------------------------------------------------------------------------
CREATE TABLE "Invoice" (
  "idInvoice" bigserial NOT NULL,
  "Employee_idEmployee" INTEGER NOT NULL,
  "Customer_idCustomer" INTEGER NOT NULL,
  "date" DATE NULL,
  "sum" NUMERIC NULL,
  "is_reversal" BOOL NULL DEFAULT 'FALSE',
  PRIMARY KEY ("idInvoice")
);

-- -------------------------------------------------------------------------
-- Table: Invoice_has_Book
-- -------------------------------------------------------------------------
CREATE TABLE "Invoice_has_Book" (
  "Invoice_idInvoice" INTEGER NOT NULL,
  "Book_isbn" INTEGER NOT NULL,
  "num" INTEGER NULL,
  "num_reversal" INTEGER NULL,
  PRIMARY KEY ("Invoice_idInvoice", "Book_isbn")
);

-- -------------------------------------------------------------------------
-- Table: Cancellation
-- -------------------------------------------------------------------------
CREATE TABLE "Cancellation" (
  "Invoice_idInvoice" INTEGER NOT NULL,
  "comment_info" VARCHAR NULL
);

-- -------------------------------------------------------------------------
-- Relations for table: News
-- -------------------------------------------------------------------------
ALTER TABLE "News" ADD FOREIGN KEY ("Customer_idCustomer") 
    REFERENCES "Customer" ("idCustomer")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: Book
-- -------------------------------------------------------------------------
ALTER TABLE "Book" ADD FOREIGN KEY ("Publisher_idPublisher") 
    REFERENCES "Publisher" ("idPublisher")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: BookOrder
-- -------------------------------------------------------------------------
ALTER TABLE "BookOrder" ADD FOREIGN KEY ("Employee_idEmployee") 
    REFERENCES "Employee" ("idEmployee")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;
ALTER TABLE "BookOrder" ADD FOREIGN KEY ("Customer_idCustomer") 
    REFERENCES "Customer" ("idCustomer")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: Order_consists_of
-- -------------------------------------------------------------------------
ALTER TABLE "Order_consists_of" ADD FOREIGN KEY ("BookOrder_idBookOrder") 
    REFERENCES "BookOrder" ("idBookOrder")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;
ALTER TABLE "Order_consists_of" ADD FOREIGN KEY ("Book_isbn") 
    REFERENCES "Book" ("isbn")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: Invoice
-- -------------------------------------------------------------------------
ALTER TABLE "Invoice" ADD FOREIGN KEY ("Employee_idEmployee") 
    REFERENCES "Employee" ("idEmployee")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;
ALTER TABLE "Invoice" ADD FOREIGN KEY ("Customer_idCustomer") 
    REFERENCES "Customer" ("idCustomer")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: Invoice_has_Book
-- -------------------------------------------------------------------------
ALTER TABLE "Invoice_has_Book" ADD FOREIGN KEY ("Invoice_idInvoice") 
    REFERENCES "Invoice" ("idInvoice")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;
ALTER TABLE "Invoice_has_Book" ADD FOREIGN KEY ("Book_isbn") 
    REFERENCES "Book" ("isbn")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

-- -------------------------------------------------------------------------
-- Relations for table: Cancellation
-- -------------------------------------------------------------------------
ALTER TABLE "Cancellation" ADD FOREIGN KEY ("Invoice_idInvoice") 
    REFERENCES "Invoice" ("idInvoice")
      ON DELETE NO ACTION
      ON UPDATE NO ACTION;

