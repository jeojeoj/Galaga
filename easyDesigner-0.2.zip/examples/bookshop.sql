CREATE TABLE Employee (
  idEmployee INTEGER NOT NULL AUTO_INCREMENT,
  name VARCHAR NULL,
  address VARCHAR NULL,
  sex BIT NULL,
  PRIMARY KEY(idEmployee)
);

CREATE TABLE Customer (
  idCustomer INTEGER NOT NULL AUTO_INCREMENT,
  name VARCHAR NULL,
  address VARCHAR NULL,
  phone VARCHAR NULL,
  smartcard INTEGER NULL,
  discount NUMERIC NULL DEFAULT 1.00,
  PRIMARY KEY(idCustomer)
);

CREATE TABLE News (
  idNews INTEGER NOT NULL AUTO_INCREMENT,
  Customer_idCustomer INTEGER NOT NULL,
  date DATE NULL,
  content VARCHAR NULL,
  already_read BOOL NULL DEFAULT FALSE,
  PRIMARY KEY(idNews),
  INDEX FKIndex1(Customer_idCustomer),
  FOREIGN KEY(Customer_idCustomer)
    REFERENCES Customer(idCustomer)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Book (
  isbn INTEGER NOT NULL,
  Publisher_idPublisher INTEGER NOT NULL,
  author VARCHAR NULL,
  title VARCHAR NULL,
  pub_year INTEGER NULL,
  selling_price NUMERIC NULL,
  buying_price NUMERIC NULL,
  num_available INTEGER NULL,
  num_min INTEGER NULL,
  num_max INTEGER NULL,
  PRIMARY KEY(isbn),
  INDEX FKIndex1(Publisher_idPublisher),
  FOREIGN KEY(Publisher_idPublisher)
    REFERENCES Publisher(idPublisher)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Publisher (
  idPublisher INTEGER NOT NULL AUTO_INCREMENT,
  name VARCHAR NULL,
  address VARCHAR NULL,
  phone VARCHAR NULL,
  PRIMARY KEY(idPublisher)
);

CREATE TABLE BookOrder (
  idBookOrder INTEGER NOT NULL AUTO_INCREMENT,
  Employee_idEmployee INTEGER NULL,
  Customer_idCustomer INTEGER NULL,
  date DATE NULL,
  PRIMARY KEY(idBookOrder),
  INDEX FKIndex1(Employee_idEmployee),
  INDEX FKIndex2(Customer_idCustomer),
  FOREIGN KEY(Employee_idEmployee)
    REFERENCES Employee(idEmployee)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Customer_idCustomer)
    REFERENCES Customer(idCustomer)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Order_consists_of (
  BookOrder_idBookOrder INTEGER NOT NULL,
  Book_isbn INTEGER NOT NULL,
  PRIMARY KEY(BookOrder_idBookOrder, Book_isbn),
  INDEX FKIndex1(BookOrder_idBookOrder),
  INDEX FKIndex2(Book_isbn),
  FOREIGN KEY(BookOrder_idBookOrder)
    REFERENCES BookOrder(idBookOrder)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Book_isbn)
    REFERENCES Book(isbn)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Invoice (
  idInvoice INTEGER NOT NULL AUTO_INCREMENT,
  Employee_idEmployee INTEGER NOT NULL,
  Customer_idCustomer INTEGER NOT NULL,
  date DATE NULL,
  sum NUMERIC NULL,
  is_reversal BOOL NULL DEFAULT FALSE,
  PRIMARY KEY(idInvoice),
  INDEX FKIndex1(Employee_idEmployee),
  INDEX FKIndex2(Customer_idCustomer),
  FOREIGN KEY(Employee_idEmployee)
    REFERENCES Employee(idEmployee)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Customer_idCustomer)
    REFERENCES Customer(idCustomer)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Invoice_has_Book (
  Invoice_idInvoice INTEGER NOT NULL,
  Book_isbn INTEGER NOT NULL,
  num INTEGER NULL,
  num_reversal INTEGER NULL,
  PRIMARY KEY(Invoice_idInvoice, Book_isbn),
  INDEX FKIndex1(Invoice_idInvoice),
  INDEX FKIndex2(Book_isbn),
  FOREIGN KEY(Invoice_idInvoice)
    REFERENCES Invoice(idInvoice)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION,
  FOREIGN KEY(Book_isbn)
    REFERENCES Book(isbn)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

CREATE TABLE Cancellation (
  Invoice_idInvoice INTEGER NOT NULL,
  comment_info VARCHAR NULL,
  INDEX FKIndex1(Invoice_idInvoice),
  FOREIGN KEY(Invoice_idInvoice)
    REFERENCES Invoice(idInvoice)
      ON DELETE NO ACTION
      ON UPDATE NO ACTION
);

