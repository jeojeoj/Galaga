public class Hilo implements Runnable{
		String txt;
		Thread thread=null;
		public Hilo(String a){
			txt=a;
		}

		public void start(){
			if(thread==null){
				thread=new Thread(this,"");
				thread.start();
			}
		}

		public void run(){
			thread.setPriority(Thread.MIN_PRIORITY+1);
			while(thread!=null){
				try{
					thread.sleep(500);
					System.out.println(txt);
				}
				catch(Exception e){

				}
			}
			thread=null;
		}

	}
